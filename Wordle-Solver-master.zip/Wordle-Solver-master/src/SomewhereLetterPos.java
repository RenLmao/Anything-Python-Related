public class SomewhereLetterPos {
    private int index;
    private String string;
    public SomewhereLetterPos(String string, int index) {
        this.index = index;
        this.string = string;
    }
    public String getString() {
        return string;
    }
    public int getIndex() {
        return index;
    }
}
