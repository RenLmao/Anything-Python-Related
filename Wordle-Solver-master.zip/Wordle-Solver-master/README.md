# Wordle-Solver
Wordle Solver becuase why not? Creddit to dracos for words.txt (https://gist.github.com/dracos/dd0668f281e685bad51479e5acaadb93)
Must be used in a terminal cause i'm not making a gui
And yes I know the code is bad af but I'm not fixing it :)
