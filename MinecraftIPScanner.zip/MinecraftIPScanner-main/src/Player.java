public class Player {
    String name;
    String id;
    public Player(String name, String id) {
        this.name = name;
        this.id = id;
    }
    public String getID() {
        return id;
    }
    public String getName() {
        return name;
    }
}
